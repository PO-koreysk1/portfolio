<?php


function addUniqueText(string $cityTag): void
{
    global $wpdb;
    $rubrics = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_rubric");
    // получить новые шаблоны
    $allTemplateData = include __DIR__ . "/newTemplateArticle.php";

    foreach ($allTemplateData as $templateData) {
        foreach ($rubrics as $rubric) {
            if ($templateData['category'] != $rubric->template_article_name) {
                continue;
            }

            $title = replaceTextForPage(
                text: $templateData['title'],
                rubricType: $rubric->template_article_name,
                postName: $rubric->tag
            );

            $contentBeforeMfo = replaceTextForPage(
                text: $templateData['content_before_mfo'],
                rubricType: $rubric->template_article_name,
                postName: $rubric->tag
            );

            $contentAfterMfo = replaceTextForPage(
                text: $templateData['content_after_mfo'],
                rubricType: $rubric->template_article_name,
                postName: $rubric->tag
            );

            $wpdb->insert(
                $wpdb->get_blog_prefix() . "creator_unique_template_for_article",
                [
                    'city_tag' => $cityTag,
                    'category' => "zaem",
                    'rubric' => $rubric->template_article_name,
                    'article' => $rubric->tag,
                    'name' => "{$cityTag}_zaem_{$rubric->tag}",
                    'title' => $title,
                    'content_before_mfo' => $contentBeforeMfo,
                    'content_after_mfo' => $contentAfterMfo,
                    'meta_title' => $templateData['meta_title'],
                    'meta_description' => $templateData['meta_description'],
                ]
            );


        }
    }
    $wpdb->insert(
        $wpdb->get_blog_prefix() . "creator_city_with_unique_text",
        [
            'city_name' => $cityTag
        ]
    );
}


function replaceTextForPage(string $text, string $rubricType, string $postName): string
{
    $text = replaceForKey($text, $rubricType, $postName);
    return replaceForText($text);

}


function replaceForKey(string $string, string $rubricType, string $postName): string
{
    $dataForKey = include __DIR__ . "/replaceDataForKey.php";

    /** @var array $value */
    foreach ($dataForKey[$rubricType] as $key => $value) {
        $string = str_replace($key, $value[$postName], $string);
    }
    return $string;
}

function replaceForText(string $string): string
{
    $dataForText = include __DIR__ . "/replaceDataForText.php";

    foreach ($dataForText as $key => $value) {
        $string = str_replace($key, $value[array_rand($value)], $string);
    }
    return $string;
}