<?php


$selectedMfo = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_mfo WHERE id = $mfoId");
$selectedMfo = empty($selectedMfo) ? [] : $selectedMfo[0];
$posts = empty($selectedMfo) ? [] :
    $wpdb->get_results("SELECT post_name FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts WHERE mfo_ids LIKE '%,{$selectedMfo->id},%'");
?>


<select id="creatorSelectRegion" name="creatorSelectRegion" onchange="citiesForSelectedRegion()">
    <option value="0">Выберите регион</option>

    <?php
    foreach ($regionsForSelectedPosts as $regionForSelectedPost) {
        ?>
        <option regionId="<?= $regionForSelectedPost->code ?>"
            <?php
            if ($creatorSelectedRegionId == $regionForSelectedPost->code) {
                echo "selected";
            }
            ?>
                value="<?= $regionForSelectedPost->code ?>"><?= $regionForSelectedPost->name ?> </option>
        <?php
    }
    ?>
</select>

<select id="creatorSelectCity" name="creatorSelectCity">
    <option value="">Выберите город</option>

    <?php

    foreach ($citiesForSelectedPosts as $cityForSelectedPost) {
        ?>

        <option class="creatorCityForSelectedRegion" region_code="<?= $cityForSelectedPost->region_code ?>"
            <?php
            if ($creatorSelectedCityId == $cityForSelectedPost->id) {
                echo "selected";
            }
            ?>
                value="<?= $cityForSelectedPost->id ?>"><?= $cityForSelectedPost->name ?></option>

        <?php

    }
    ?>
</select>


<div
    <?php
    $cityTag = "";
    if (!empty($creatorSelectedRegionId) && !empty($creatorSelectedCityId)) {

        global $wpdb;
        $city = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE id = $creatorSelectedCityId")[0];
        $cityTag = $city->tag;
    }
    ?>
>

    <label><input type="checkbox" id="creatorSelectAllPost" onchange="selectAllRubric()">Выбрать все </label>
    <fieldset class="razvernut">
        <?php
        foreach ($rubricsForSelectedPost as $mfoRubric) {
            ?>
            <label><input type="checkbox" name="rubric[]" class="creatorSelectorRubric"

                    <?php

                    foreach ($posts as $post) {
                        if ($cityTag . "_zaem_" . $mfoRubric->tag == $post->post_name)
                            echo "checked";
                    }

                    ?>
                          value="<?= $cityTag . "_zaem_" . $mfoRubric->tag ?>"><?= $mfoRubric->title ?>
            </label>
        <?php } ?>
    </fieldset>
</div>
<script>
    function citiesForSelectedRegion() {
        let region = document.getElementById("creatorSelectRegion")

        let cities = document.querySelectorAll(".creatorCityForSelectedRegion")

        for (let i = 0; i < cities.length; i++) {
            let city = cities[i]

            let regionCodeByCities = city.getAttribute("region_code")
            let regionCode = region.value


            if (regionCodeByCities !== regionCode) {
                city.setAttribute("hidden", true)
            }

            if (regionCodeByCities === regionCode) {
                city.removeAttribute("hidden")
            }
        }

    }


    function selectAllRubric() {
        let selectAll = document.getElementById("creatorSelectAllPost")
        let isCheck = selectAll.checked

        let rubrics = document.querySelectorAll(".creatorSelectorRubric")

        for (let i = 0; i < rubrics.length; i++) {
            let rubric = rubrics[i]
            if (isCheck) {
                rubric.setAttribute("checked", isCheck)
            } else {
                rubric.removeAttribute("checked")
            }

        }
    }


</script>
