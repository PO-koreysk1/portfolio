<?php
add_action('admin_post_open_to_index', 'openToIndex');

function openToIndex()
{
    global $wpdb;

    $city = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE id = {$_POST['creatorSelectCity']}")[0];
    foreach ($_POST["rubric"] as $rubric) {
        $postName = $city->tag . $rubric;


        $wpdb->update(
            $wpdb->prefix . 'creator_organizations_attached_to_posts',
            array('is_close' => 1),
            array(
                'post_name' => $postName,
            ),
        );
    }
}