<?php
include __DIR__ . "/createPosts.php";
include __DIR__ . "/createCitiesPage.php";
include __DIR__ . "/attachmentMfo.php";
include __DIR__ . "/addMfo.php";
include __DIR__ . "/openToIndex.php";
include __DIR__ . "/attachmentMfoData.php";
include __DIR__ . "/attachMfoByCategory.php";
include __DIR__ . "/attachMfoInTheSameWayAsInMoskov.php";
include __DIR__ . "/createUniqueTextForPage.php";


$action = $_POST["action"] ?? null;

if (!empty($action)) {
    do_action("admin_post_$action");
}
$creatorSelectedRegionId = $_POST["creatorSelectRegion"] ?? "";
$creatorSelectedCityId = $_POST["creatorSelectCity"] ?? "";
$mfoId = $_POST["selectMfo"] ?? '';
?>
<body id="test">
<div class="container">
    <h3>Добавление термов и страниц</h3>

    <div class="instruction">Инструкция: для корректной работы плагина сначала создаются страницы для городов и
        категорий, а после страницы постов
    </div>


    <div class="action-container">
        <span class="action-label">Сгенерировать страницы городов и категорий</span>
        <div class="action-form">
            <form action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>" method="post">
                <input type="hidden" name="action" value="create_cities_page">
                <button type="submit" class="submit-btn">Создать</button>
            </form>
        </div>
    </div>
    <hr>

    <div class="action-container" style="flex-wrap: wrap !important;">
        <div style="width: 100%; padding-top: 10px; padding-bottom: 20px">
            <span style="font-size: 17px" class="action-label">Сгенерировать уникальные тексты для страниц</span>
        </div>
        <div class="action-form">
            <form action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>" method="post">
                <?php
               if ($_POST["cityForCreateUniqueText"] == "#" && empty($_POST["selectAllCityForCreateUniqueText"])){
//                   ?>
                   <span style="font-size: 17px; color: red; margin-bottom: 10px"  class="action-label">Не выбраны города для генерации текстов</span>
                <?php
               }
                global $wpdb;

                $allCityTagObj = $wpdb->get_results("SELECT `tag` FROM {$wpdb->get_blog_prefix()}creator_city");
                $allCityTag = [];
                foreach ($allCityTagObj as $cityTagObj) {
                    $allCityTag[] = $cityTagObj->tag;
                }
                $allCityTagString = "'" . implode("','", $allCityTag) . "'";

                $namesOfCitiesWithGeneratedPosts =
                    $wpdb->get_results("SELECT `post_title` FROM {$wpdb->get_blog_prefix()}posts WHERE post_title IN($allCityTagString)");

                ?>
                <div>
                    <label><input name="selectAllCityForCreateUniqueText" type="checkbox"> Сгенерировать текст по всем городам</label>
                </div>
                <div>
                    <label>
                        <select name="cityForCreateUniqueText" class="selectStyleCreator">
                            <option value="#" selected> Выберете город</option>
                            <?php
                            foreach ($namesOfCitiesWithGeneratedPosts as $cityName) {
                                ?>
                                <option value="<?= $cityName->post_title ?>"><?= $cityName->post_title ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </label>
                </div>

                <div style="padding-top: 15px">
                    <input type="hidden" name="action" value="create_unique_textF_for_page">
                    <button type="submit" class="submit-btn">Создать</button>
                </div>

            </form>
        </div>
    </div>
    <hr>

    <div class="action-container">
        <span class="action-label">Сгенерировать посты</span>
        <div class="action-form">
            <form action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>" method="post">
                <input type="hidden" name="action" value="create_posts">
                <button type="submit" class="submit-btn">Создать</button>
            </form>
        </div>
    </div>
    <hr>
    <?php
    if (empty($_POST["isAllPosts"]) && !empty($_POST["postsCounter"])) {
        ?>
        <input type="hidden" name="postsCounter" value="<?= $_POST["postsCounter"] ?>"
               hx-post="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
               hx-trigger="load"
               hx-include="[id='additional_shipping_posts']"
               hx-swap="outerHTML"
               hx-target="#test"
        >
        <input type="hidden" id="additional_shipping_posts" name="action" value="create_posts">
        <?php

        ?>

        <div>
            Создано записей для <?= $_POST['postsCounter'] ?? "" ?> города(-ов) из <?= $_POST['allPosts'] ?? "" ?>
        </div>
        <?php
    }
    ?>

    <div class="action-container">
        <span class="action-label">Добавить/Обновить МФО</span>
        <div class="action-form">
            <form action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>" method="post">
                <input type="hidden" name="action" value="add_mfo">
                <button type="submit" class="submit-btn">Добавить</button>
            </form>
        </div>
    </div>
    <hr>
    <div class="action-container">
        <span class="action-label">Привязать мфо как в Москве</span>
        <div class="action-form">
            <form action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>" method="post">
                <input type="hidden" name="action" value="attach_in_the_same_way_as_in_Moskov">
                <button type="submit" class="submit-btn">Добавить</button>
            </form>
        </div>
    </div>
</div>
<br>


<div>
    <h3>Прикрепление МФО к страницам</h3>
    <div class="attachmentForm">
        <form
                name="attachmentForm"
                class="treeHTML"
                class="razvernut"
                action="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
                method="post"
        >

            <?php
            include __DIR__ . "/selectedPosts.php"
            ?>

        </form>

        <!-- Изменение МФО и запрос для отображения выбранных постов-->
        <input type="hidden" name="action_select" value="show_selected_posts" id="show_selected_posts">

        <div class="selectMfo">

            <select name="selectMfo" id="selectedMfo"
                    hx-post="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
                    hx-trigger="change"
                    hx-swap="outerHTML"
                    hx-target="#test"
                    hx-include="[id='creatorSelectRegion'],[id='creatorSelectCity']"
            >
                <option value="">Выберете мфо</option>

                <?php
                foreach (getMfo() as $organization) { ?>

                    <option value="<?= $organization->id ?>"

                        <?php if ($mfoId == $organization->id) {
                            echo "selected";
                        } ?>

                    ><?= $organization->name ?>
                    </option>

                <?php } ?>
            </select>
        </div>

        <!--отправка формы-->
        <div>
            <input type="hidden" name="action" value="attachment_mfo" id="submit_form">
            <button type="button" class="submit-btn attachmentMfo"
                <?php
                if (!empty($creatorSelectedRegionId) && !empty($creatorSelectedCityId) && !empty($mfoId)) {
                    ?>
                    hx-post="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
                    hx-trigger="click"
                    hx-swap="none"
                    hx-target="#test"
                    hx-include="[name='attachmentForm'],[id='selectedMfo'],[id='submit_form']"

                    <?php
                }
                ?>

            >Прикрепить
            </button>
        </div>

        <div>
            <input type="hidden" name="action" value="open_to_index" id="open_to_index">
            <button type="button" class="submit-btn openToIndex"
                    hx-post="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
                    hx-trigger="click"
                    hx-swap="outerHTML"
                    hx-target="#test"
                    hx-include="[name='attachmentForm'],[id='open_to_index']"

            >Открыть для индексации
            </button>
        </div>

    </div>

</div>
<?php include __DIR__ . "/formAttachByCategory.php"; ?>


</body>