<?php
global $wpdb;

$regionsForSelectedPosts = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_region WHERE 1");
$citiesForSelectedPosts = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE  category_id LIKE '%,1,%'");
$rubricsForSelectedPost = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_rubric WHERE `category_id` = 1");

function getMfo():array
{
    global $wpdb;

    return $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_mfo ORDER BY name ASC");
}