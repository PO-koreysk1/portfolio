<div style="margin-top: 30px">
    <div>
        <h3>Прикрепление МФО к общим страницам категорий </h3>
    </div>
    <div class="attachmentForm">
        <form name="attachMfoInCategory">
            <div style="width:50%;display: flex;flex-wrap:wrap; column-gap 20px;height: min-content">
                <select name="creatorSelectRegionByCategory" id="creatorSelectRegionByCategory"
                        onchange="citiesForSelectedRegionByCategory()">
                    <option value="">Выберете регион</option>
                    <?php
                    foreach ($regionsForSelectedPosts as $region) { ?>

                        <option
                                regionId="<?= $region->code ?>"

                                value="<?= $region->code ?>"><?= $region->name ?></option>

                    <?php } ?>
                </select>

                <select name="creatorSelectCityByCategory" id="creatorSelectCityByCategory">
                    <option value="">Выберете город</option>
                    <?php
                    foreach ($citiesForSelectedPosts as $city) { ?>

                        <option
                                class="creatorCityForSelectedRegionByCategory"
                                region_code="<?= $city->region_code ?>"
                                value="<?= $city->id ?>"><?= $city->name ?></option>

                    <?php } ?>
                </select>
                <select name="creatorSelectCategoryByCategory" id="creatorSelectCategoryByCategory">
                    <option value="">Выберете категорию</option>
                    <option value="1">Займы</option>
                </select>

            </div>
            <div>
                <div>
                    <label><input type="checkbox" id="creatorSelectAllMfoByCategory" onchange="selectAllMfoByRubric()">Выбрать
                        все </label>
                    <fieldset class="razvernut">
                        <?php
                        foreach (getMfo() as $mfo) {
                            ?>
                            <label><input type="checkbox" name="mfos[]" class="creatorSelectorByCategory"
                                          value="<?= $mfo->id ?>"><?= $mfo->name ?>
                            </label>
                        <?php } ?>
                    </fieldset>
                </div>
            </div>

        </form>
    </div>

    <div>
        <input type="hidden" name="action" value="add_mfo_in_category" id="add_mfo_in_category">
        <button type="button" class="submit-btn"
                hx-post="<?= esc_url(admin_url('admin.php?page=creator-page')); ?>"
                hx-trigger="click"
                hx-swap="outerHTML"
                hx-target="#test"
                hx-include=
                "[name='creatorSelectRegionByCategory'],
                [name='creatorSelectCityByCategory'],
                [name='creatorSelectCategoryByCategory'],
                [name='attachMfoInCategory'],
                [id='add_mfo_in_category']"
        >
            Привязать МФО
        </button>
    </div>
</div>


<script>
    function citiesForSelectedRegionByCategory() {
        let region = document.getElementById("creatorSelectRegionByCategory")

        let cities = document.querySelectorAll(".creatorCityForSelectedRegionByCategory")

        for (let i = 0; i < cities.length; i++) {
            let city = cities[i]

            let regionCodeByCities = city.getAttribute("region_code")
            let regionCode = region.value


            if (regionCodeByCities !== regionCode) {
                city.setAttribute("hidden", true)
            }

            if (regionCodeByCities === regionCode) {
                city.removeAttribute("hidden")
            }
        }

    }


    function selectAllMfoByRubric() {
        let selectAll = document.getElementById("creatorSelectAllMfoByCategory")
        let isCheck = selectAll.checked

        let rubrics = document.querySelectorAll(".creatorSelectorByCategory")

        for (let i = 0; i < rubrics.length; i++) {
            let rubric = rubrics[i]
            if (isCheck) {
                rubric.setAttribute("checked", isCheck)
            } else {
                rubric.removeAttribute("checked")
            }

        }
    }

</script>