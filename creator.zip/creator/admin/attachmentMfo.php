<?php
add_action('admin_post_attachment_mfo', 'attachmentMfo');

function attachmentMfo()
{
    global $wpdb;

    $rubrics = $_POST["rubric"] ?? [];
    $mfoId = $_POST["selectMfo"];

    $mfo = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_mfo WHERE `id` = $mfoId")[0];

    // удаление мфо из записей
    $allArticleByMfo = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts WHERE mfo_ids LIKE '%,{$mfo->id},%';");

    if (!empty($allArticleByMfo)) {
        foreach ($allArticleByMfo as $articleByMfo) {
            if (in_array($articleByMfo->post_name, $rubrics)) {
                continue;
            }
            $data = str_replace(",{$mfo->id},", ",", $articleByMfo->mfo_ids);
            $wpdb->update(
                $wpdb->prefix . 'creator_organizations_attached_to_posts',
                array('mfo_ids' => $data),
                array(
                    'id' => $articleByMfo->id,
                ),
            );
        }
    }

    // добавление  мфо в записи
    if (!empty($rubrics)) {
        foreach ($rubrics as $rubric) {
            $articleByPostName = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts WHERE `post_name` = '$rubric'");

            if (empty($articleByPostName)) {
                continue;
            }
            $articleByPostName = $articleByPostName[0];

            if (in_array($mfo->id, explode(",", $articleByPostName->mfo_ids))) {
                continue;
            }

            $data = str_replace(",,", ",", $articleByPostName->mfo_ids . ",{$mfo->id},");
            $wpdb->update(
                $wpdb->prefix . 'creator_organizations_attached_to_posts',
                array('mfo_ids' => $data),
                array(
                    'id' => $articleByPostName->id,
                ),
            );

        }
    }


}
