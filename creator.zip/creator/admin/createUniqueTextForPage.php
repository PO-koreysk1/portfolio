<?php
add_action('admin_post_create_unique_textF_for_page', 'createUniqueTextForPage');
include_once __DIR__ . "/../replaceService/replaceService.php";
function createUniqueTextForPage()
{
    global $wpdb;

    $cities = $_POST["selectAllCityForCreateUniqueText"] ?? null;
    if (null === $cities) {
        $city = $_POST["cityForCreateUniqueText"];
        if ($city != "#") {
            $cityWithUniqueText = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city_with_unique_text WHERE `city_name` = {$city}");
            if (empty($cityWithUniqueText)) {
                addUniqueText($city);
            }
            return;
        }
    }
    // получение всех городов
    $allCityTagObj = $wpdb->get_results("SELECT `tag` FROM {$wpdb->get_blog_prefix()}creator_city");
    $allCityTag = [];
    foreach ($allCityTagObj as $cityTagObj) {
        $allCityTag[] = $cityTagObj->tag;
    }

    // получаем все города, по которым сгенерированы посты
    $allCityTagString = "'" . implode("','", $allCityTag) . "'";
    $namesOfCitiesWithGeneratedPostsObj =
        $wpdb->get_results("SELECT `post_title` FROM {$wpdb->get_blog_prefix()}posts WHERE post_title IN($allCityTagString)");
    $namesOfCitiesWithGeneratedPosts = [];
    foreach ($namesOfCitiesWithGeneratedPostsObj as $cityTag) {
        $namesOfCitiesWithGeneratedPosts[] = $cityTag->post_title;
    }

    // получение всех городов по которым уе сгенерированы тексты
    $allCityWithUniqueTextObj = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city_with_unique_text");
    $allCityWithUniqueText = [];
    foreach ($allCityWithUniqueTextObj as $CityWithUniqueTextObj) {
        $allCityWithUniqueText[] = $CityWithUniqueTextObj->city_name;
    }

    // проходимся по всем городам, если город уже есть в базе, генерируем
    foreach ($namesOfCitiesWithGeneratedPosts as $cityTag) {
        if (in_array($cityTag, $allCityWithUniqueText)) {
            continue;
        }
        addUniqueText($cityTag);
    }


}
