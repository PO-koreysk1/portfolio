<?php

add_action('admin_post_create_posts', 'createPosts');

function createPosts()
{
    global $wpdb;

    $cities = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE tag = 'Sankt-Peterburg' ORDER BY id ASC");

    $counter = $_POST["postsCounter"] ?? 0;
    $range = min(count($cities) - $counter, 1);
    $rubrics = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_rubric WHERE category_id = 1");

    for ($i = $counter; $i < $counter + $range; $i++) {
        $city = $cities[$i];


        foreach ($rubrics as $rubric) {
            wp_insert_post(
                [
                    'post_title' => $city->tag . "_zaem_" . $rubric->tag,
                    'post_content' => $city->tag . "_zaem_" . $rubric->tag,
                    'post_name' => $city->tag . "_zaem_" . $rubric->tag,
                    'post_type' => 'creator',
                    'post_status' => 'publish',
                ]
            );

            $wpdb->insert(
                $wpdb->get_blog_prefix() . "creator_organizations_attached_to_posts",
                [
                    'post_name' => $city->tag . "_zaem_" . $rubric->tag
                ]
            );
        }
    }
    if ($i >= count($cities)) {
        $_POST["isAllPosts"] = true;
    }
    $_POST["postsCounter"] = $i;
    $_POST["allPosts"] = count($cities);
}