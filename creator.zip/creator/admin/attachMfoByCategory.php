<?php

add_action('admin_post_add_mfo_in_category', 'addMfoInCategory');


function addMfoInCategory()
{
    global $wpdb;

    $mfoIdsArr = $_POST["mfos"];


    $cityId = $_POST['creatorSelectCityByCategory'];
    $city = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE id = $cityId")[0];

    $categoryId = $_POST["creatorSelectCategoryByCategory"];
    $category = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_category WHERE id = $categoryId")[0];


    if (empty($mfoIdsArr)) {
        $wpdb->update(
            $wpdb->prefix . 'creator_organizations_attached_to_posts',
            array('mfo_ids' => ''),
            array(
                'post_name' =>  $city->tag . "_" . $category->tag,
            ),
        );

        return;
    }





    $object = $wpdb->get_results(
        "SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts 
         WHERE post_name = '{$city->tag}_{$category->tag}'"
    );

    $mfoIds = "," . implode(",", $mfoIdsArr) . ",";
    if (empty($object)) {

        $wpdb->insert(
            $wpdb->get_blog_prefix() . "creator_organizations_attached_to_posts",
            [
                'post_name' => $city->tag . "_" . $category->tag,
                'mfo_ids' => $mfoIds,
                "is_close" => 0
            ]
        );
    }
    else{
        $wpdb->update(
            $wpdb->prefix . 'creator_organizations_attached_to_posts',
            array('mfo_ids' => $mfoIds),
            array(
                'post_name' =>  $city->tag . "_" . $category->tag,
            ),
        );
    }
}