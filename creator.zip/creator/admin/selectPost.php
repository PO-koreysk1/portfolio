<?php

add_action('admin_post_selected_posts', 'selectedPosts');


function selectedPosts() {
    global $wpdb;
    $mfoId = $_POST['selectMfo'] ?? "";

    $selectedMfo = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_mfo WHERE id = $mfoId");
    $selectedMfo = empty($selectedMfo) ? [] : $selectedMfo[0];
    $posts = empty($selectedMfo) ? [] :
        $wpdb->get_results("SELECT post_name FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts WHERE mfo_ids LIKE '%,{$selectedMfo->id},%'");


    $selectedRegion = [];
    $selectedCity = [];
    $selectedRubric = [];

    foreach ($posts as $post) {
        $postData = explode("_", $post->post_name);
        $selectedCity[] = $postData[0];
        $selectedRubric[] = $post->post_name;

        $sql = <<<SQL
                SELECT * FROM {$wpdb->get_blog_prefix()}creator_region 
                WHERE code = (
                    SELECT region_code FROM {$wpdb->get_blog_prefix()}creator_city WHERE tag = '{$postData[0]}'
                )
SQL;

        $selectedRegion[] = $wpdb->get_results($sql)[0]->id;
    }

    if (empty($mfoId) || empty($selectedMfo) || empty($posts)) {
        $_POST["selected_posts"] = "no_selected";
    } else {
// todo добавить выбор
        $posts = $wpdb->get_results("SELECT post_name FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts WHERE mfo_ids LIKE '%,{$selectedMfo->id},%'");
        $_POST["selected_posts"] = "selected";

    }
}

?>


<!--<script>-->
<!--    var t = document.forms.attachmentForm;-->
<!--    [].forEach.call(t.querySelectorAll('fieldset'), function (eFieldset) {-->
<!--        var main = [].filter.call(t.querySelectorAll('[type="checkbox"]'), function (element) {-->
<!--            return element.parentNode.nextElementSibling == eFieldset;-->
<!--        });-->
<!--        main.forEach(function (eMain) {-->
<!--            var l = [].filter.call(eFieldset.querySelectorAll('legend'), function (e) {-->
<!--                return e.parentNode == eFieldset;-->
<!--            });-->
<!--            l.forEach(function (eL) {-->
<!--                var all = eFieldset.querySelectorAll('[type="checkbox"]');-->
<!--                eL.onclick = Razvernut;-->
<!--                eFieldset.onchange = Razvernut;-->
<!---->
<!--                function Razvernut() {-->
<!--                    var allChecked = eFieldset.querySelectorAll('[type="checkbox"]:checked').length;-->
<!--                    eMain.checked = allChecked == all.length;-->
<!--                    eMain.indeterminate = allChecked > 0 && allChecked < all.length;-->
<!--                    if (eMain.indeterminate || eMain.checked || ((eFieldset.className == '') && (allChecked == "0"))) {-->
<!--                        eFieldset.className = 'razvernut';-->
<!--                    } else {-->
<!--                        eFieldset.className = '';-->
<!--                    }-->
<!--                }-->
<!---->
<!--                eMain.onclick = function () {-->
<!--                    for (var i = 0; i < all.length; i++)-->
<!--                        all[i].checked = this.checked;-->
<!--                    if (this.id() !== 'all') {-->
<!---->
<!---->
<!--                        if (this.checked) {-->
<!--                            eFieldset.className = 'razvernut';-->
<!--                        } else {-->
<!--                            eFieldset.className = '';-->
<!--                        }-->
<!--                    }-->
<!--                }-->
<!--            });-->
<!--        });-->
<!--    });-->
<!--</script>-->