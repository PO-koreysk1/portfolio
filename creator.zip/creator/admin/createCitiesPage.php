<?php
add_action('admin_post_create_cities_page', 'createCitiesPage');

function createCitiesPage()
{
    global $wpdb;

    $allCity = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE  tag = 'Sankt-Peterburg' ORDER BY id ASC");

    foreach ($allCity as $city) {
        wp_insert_post(
            [
                'post_title' => $city->tag,
                'post_content' => $city->tag,
                'post_name' => $city->tag,
                'post_type' => 'creator',
                'post_status' => 'publish',
            ]
        );

        wp_insert_post(
            [
                'post_title' => $city->tag . '_zaem',
                'post_content' => $city->tag . '_zaem',
                'post_name' => $city->tag . '_zaem',
                'post_type' => 'creator',
                'post_status' => 'publish',
            ]
        );
    }
}