<?php
add_action('admin_post_attach_in_the_same_way_as_in_Moskov', 'attachInTheSameWayAsInMoskov');


function attachInTheSameWayAsInMoskov()
{
    global $wpdb;

    $sqlForPostsInMoskov = <<<SQL
                        SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts 
                        WHERE `post_name` LIKE '%Moskva_zaem%'
SQL;

    $postsInMoskov = $wpdb->get_results($sqlForPostsInMoskov);

    foreach ($postsInMoskov as $postInMoskov) {

        $postNameArr = explode("_", $postInMoskov->post_name);
        $postNameBySql = "_{$postNameArr[1]}";
        if (count($postNameArr) >2){
            $postNameBySql .= "_{$postNameArr[2]}";
        }
        $sqlForPostByPostName = <<<SQL
                        SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts 
                        WHERE post_name LIKE '%$postNameBySql%' 
                        AND post_name NOT LIKE '%Moskva_%'
SQL;
        if (count($postNameArr) == 2 ) {
            $sqlForPostByPostName = <<<SQL
                        SELECT * FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts 
                        WHERE post_name LIKE '%$postNameBySql%' 
                        AND post_name NOT LIKE '%{$postNameBySql}_%' 
                        AND post_name NOT LIKE '%Moskva_%';
SQL;
        }

        $postsByPostName = $wpdb->get_results($sqlForPostByPostName);
        foreach ($postsByPostName as $postByPostName) {
            $wpdb->update(
                $wpdb->prefix . 'creator_organizations_attached_to_posts',
                array('mfo_ids' => $postInMoskov->mfo_ids),
                array(
                    'post_name' =>  $postByPostName->post_name,
                ),
            );
       }
    }
}