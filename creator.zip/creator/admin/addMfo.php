<?php

add_action('admin_post_add_mfo', 'addMfo');


function addMfo()
{
    global $wpdb;

    $wpdb->query($wpdb->prepare("TRUNCATE TABLE {$wpdb->get_blog_prefix()}creator_mfo"));

    $sqlForSelectMfoByPost = <<<SQL
                    SELECT * FROM {$wpdb->get_blog_prefix()}posts          
                    WHERE post_type = 'mfo' 
                    AND post_status = 'publish' 
                    AND post_parent = 0;
SQL;

    foreach ($wpdb->get_results($sqlForSelectMfoByPost) as $mfo) {
        $wpdb->insert(
            $wpdb->get_blog_prefix() . "creator_mfo",
            [
                'name' => $mfo->post_title,
                'tag' => $mfo->post_name,
            ]
        );
    }
}