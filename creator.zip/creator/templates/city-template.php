<?php
include __DIR__ . "/../function/prepareTextForArticle.php";

get_header();

$postName = substr(wpcf7_get_request_uri(), 1);

global $wpdb;

$sqlForSelectArticleTemplate = <<<SQL
         SELECT * FROM {$wpdb->get_blog_prefix()}creator_template_article_info 
         WHERE `category` = 'cityTemplate'
SQL;
$articleTemplateInfo = $wpdb->get_results($sqlForSelectArticleTemplate)[0];


$title = replaceTag(string: $articleTemplateInfo->title, city: $postName);
$contentBeforeMfo = replaceTag(string: $articleTemplateInfo->content_before_mfo, city: $postName);
$contentAfterMfo = replaceTag(string: $articleTemplateInfo->content_after_mfo, city: $postName);


?>
    <section class="section-creator">
        <div class="container-creator">
            <div>
                <div class="main-content-creator"><h1><?= $title ?></h1></div>
                <div class="main-content-creator">
                    <div>
                        <div><?= $contentBeforeMfo ?></div>
                    </div>

                </div class="main-content-creator">
            </div>

        </div>
    </section>

<?php get_template_part('popular-mfo'); ?>


    <section class="section-creator">
        <div class="container-creator">
            <div class="main-content-creator">
                <div class="before-content-creator"><?= $contentAfterMfo ?></div>
            </div>
            <div class="shareBlockCreator">
                <div class="info-article-share">
                    <div>
                        <span class="info-article-share-text">Поделиться:</span>
                    </div>
                    <div class="ya-share2" data-curtain data-color-scheme="blackwhite"
                         data-services="vkontakte,odnoklassniki,telegram"></div>
                </div>
            </div>
        </div>
    </section>

<?php get_template_part('main-new-mfo'); ?>
<?php get_template_part('fullReviews'); ?>
<?php get_template_part('main-news'); ?>
<?php get_template_part('main-catalog-links'); ?>
<?php get_template_part('main-benefit'); ?>
<?php get_template_part('faq'); ?>

<?php
get_footer();