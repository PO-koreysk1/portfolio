<?php
echo 3;