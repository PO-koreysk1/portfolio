<?php
include __DIR__ . "/../function/prepareTextForArticle.php";
include __DIR__ . "/../function/getMfo.php";

get_header();
$postName = substr(wpcf7_get_request_uri(), 1); // мб добавить -1

$rubric = end(explode("/", $postName));
$city = explode("/", $postName)[0];
global $wpdb;

$postNameForSelect = ucfirst(str_replace("/", "_", $postName));
$sqlForSelectMfoId = <<<SQL
            SELECT mfo_ids FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts
            WHERE `post_name` = '$postNameForSelect'
SQL;

$mfoIdsArticle = explode(",", $wpdb->get_results($sqlForSelectMfoId)[0]->mfo_ids);
foreach ($mfoIdsArticle as $key => $value) {
    if (empty($value)) {
        unset($mfoIdsArticle[$key]);
    }
}

$mfoIdsArticle = implode(",", $mfoIdsArticle);
//todo переделать запрос
$sqlForSelectMfo = <<<SQL
                SELECT * FROM  {$wpdb->get_blog_prefix()}creator_mfo
                WHERE `id` IN($mfoIdsArticle)
SQL;


$mfos = $wpdb->get_results($sqlForSelectMfo);
$mfoNames = [];
foreach ($mfos as $mfo) {
    $mfoNames[] = $mfo->tag;
}


$isGenerateUniqueText = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_city_with_unique_text WHERE city_name = '{$city}'");

if (isset($isGenerateUniqueText)) {
    $isGenerateUniqueText = $isGenerateUniqueText[0];

    $nameUniqueTemplate = str_replace("/", "_", $postName);
    $uniqueTemplate = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_unique_template_for_article WHERE name = '{$nameUniqueTemplate}'")[0];

    $title = $uniqueTemplate->title;
    $contentBeforeMfo = $uniqueTemplate->content_before_mfo;
    $contentAfterMfo = $uniqueTemplate->content_after_mfo;

} else {
    $sqlForSelectArticleTemplate = <<<SQL
         SELECT * FROM {$wpdb->get_blog_prefix()}creator_template_article_info 
         WHERE `category` = (
            SELECT `template_article_name` FROM {$wpdb->get_blog_prefix()}creator_rubric
            WHERE `tag` = '$rubric'
        )
SQL;
    $articleTemplateInfo = $wpdb->get_results($sqlForSelectArticleTemplate)[0];

    $title = $articleTemplateInfo->title;
    $contentBeforeMfo = $articleTemplateInfo->content_before_mfo;
    $contentAfterMfo = $articleTemplateInfo->content_after_mfo;

}

$title = replaceTag(string: $title, rubric: $rubric, city: $city);
$contentBeforeMfo = replaceTag(string: $contentBeforeMfo, rubric: $rubric, city: $city);
$contentAfterMfo = replaceTag(string: $contentAfterMfo, rubric: $rubric, city: $city);
?>

    <section class="section-creator">
        <div class="container-creator">
            <div>
                <div class="main-content-creator"><h1><?= $title ?></h1></div>
                <div class="main-content-creator">
                    <div>
                        <div><?= $contentBeforeMfo ?></div>
                        <div class="attached-mfo-creator">
                            <?php
                            getMfoForSingleCreator($mfoNames);
                            ?></div>
                    </div>
                    <?php
                    include __DIR__ . "/../public/sidebar.php";
                    ?>
                </div class="main-content-creator">
                <div class="main-content-creator">
                    <div class="before-content-creator"><?= $contentAfterMfo ?></div>
                </div>
            </div>
            <?php
            //            include __DIR__ . "/../public/linking.php";
            ?>
            <div class="shareBlockCreator">
                <div class="info-article-share">
                    <div>
                        <span class="info-article-share-text">Поделиться:</span>
                    </div>
                    <div class="ya-share2" data-curtain data-color-scheme="blackwhite"
                         data-services="vkontakte,odnoklassniki,telegram"></div>
                </div>
            </div>

        </div>

    </section>


<?php
get_footer();
