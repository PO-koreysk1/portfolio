<?php
echo 4;