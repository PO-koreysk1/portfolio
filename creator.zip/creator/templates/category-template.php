<?php
include __DIR__ . "/../function/prepareTextForArticle.php";
include __DIR__ . "/../function/getMfo.php";


get_header();

$postName = substr(wpcf7_get_request_uri(), 1);

global $wpdb;

$sqlForSelectArticleTemplate = <<<SQL
         SELECT * FROM {$wpdb->get_blog_prefix()}creator_template_article_info 
         WHERE `category` = 'categoryTemplate'
SQL;
$articleTemplateInfo = $wpdb->get_results($sqlForSelectArticleTemplate)[0];

$postNameForSelect = ucfirst(str_replace("/", "_", $postName));
$sqlForSelectMfoId = <<<SQL
            SELECT mfo_ids FROM {$wpdb->get_blog_prefix()}creator_organizations_attached_to_posts
            WHERE `post_name` = '$postNameForSelect'
SQL;

$mfoIdsArticle = explode(",", $wpdb->get_results($sqlForSelectMfoId)[0]->mfo_ids);
foreach ($mfoIdsArticle as $key => $value) {
    if (empty($value)) {
        unset($mfoIdsArticle[$key]);
    }
}
//var_dump($mfoIdsArticle);
//die();
$mfoIdsArticle = implode(",", $mfoIdsArticle);
//todo переделать запрос
$sqlForSelectMfo = <<<SQL
                SELECT * FROM  {$wpdb->get_blog_prefix()}creator_mfo
                WHERE `id` IN($mfoIdsArticle)
SQL;


$mfos = $wpdb->get_results($sqlForSelectMfo);
$mfoNames = [];
foreach ($mfos as $mfo) {
    $mfoNames[] = $mfo->tag;
}





$title = replaceTag(string: $articleTemplateInfo->title, city: explode("/", $postName)[0]);
$contentBeforeMfo = replaceTag(string: $articleTemplateInfo->content_before_mfo, city: explode("/", $postName)[0]);
$contentAfterMfo = replaceTag(string: $articleTemplateInfo->content_after_mfo, city: explode("/", $postName)[0]);


?>
    <section class="section-creator">
        <div class="container-creator">
            <div>
                <div class="main-content-creator"><h1><?= $title ?></h1></div>
                <div class="main-content-creator">
                    <div>
                        <div><?= $contentBeforeMfo ?></div>
                        <div class="attached-mfo-creator">
                            <?php
                            getMfoForSingleCreator($mfoNames);
                            ?></div>
                    </div>
                    <?php
                    include __DIR__ . "/../public/sidebar.php";
                    ?>
                </div>
                <div class="main-content-creator">
                    <div class="before-content-creator"><?= $contentAfterMfo ?></div>
                </div>
            </div>
            <?php
            //            include __DIR__ . "/../public/linking.php";
            ?>
            <div class="shareBlockCreator">
                <div class="info-article-share">
                    <div>
                        <span class="info-article-share-text">Поделиться:</span>
                    </div>
                    <div class="ya-share2" data-curtain data-color-scheme="blackwhite"
                         data-services="vkontakte,odnoklassniki,telegram"></div>
                </div>
            </div>
        </div>
    </section>
<?php
get_footer();