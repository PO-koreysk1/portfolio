<?php
return [
        [
            "name" => "Займы",
            "tag" => "zaem",
        ],
    ];