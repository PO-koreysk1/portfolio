<?php

    $file = fopen(__DIR__ . "/regions.csv", "r");
    $data = [];
    while (($row = fgetcsv($file, 0, ",")) !== false) {
        $data[] = $row;
    }
    fclose($file);

// Создаем массив с массивами в требуемом формате
    $result = [];
    foreach ($data as $row) {
        $item = [
            "name" => $row[1],
            "code" => $row[0],
        ];
        $result[] = $item;
    }

    return array_map("unserialize", array_unique(array_map("serialize", $result)));





