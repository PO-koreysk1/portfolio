<?php

$file = fopen(__DIR__ . "/cities.csv", "r");
$data = [];
while (($row = fgetcsv($file, 0, ",")) !== false) {
    $data[] = $row;
}
fclose($file);
$result = [];
foreach ($data as $row) {
    $item = [
        "name" => $row[0],
        "tag" => transliterate($row[0]),
        "region_code" => $row[1],
        "category_id" => "1"
    ];
    $result[] = $item;
}
return $result;

