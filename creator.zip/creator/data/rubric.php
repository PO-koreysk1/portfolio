<?php
return [
    //сумма
    [
        "title" => "100 рублей",
        "tag" => "100-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "200 рублей",
        "tag" => "200-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "300 рублей",
        "tag" => "300-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "500 рублей",
        "tag" => "500-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "1000 рублей",
        "tag" => "1000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "1500 рублей",
        "tag" => "1500-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "2000 рублей",
        "tag" => "2000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "2500 рублей",
        "tag" => "2500-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "3000 рублей",
        "tag" => "3000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "4000 рублей",
        "tag" => "4000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "5000 рублей",
        "tag" => "5000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "6000 рублей",
        "tag" => "6000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "7000 рублей",
        "tag" => "7000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "8000 рублей",
        "tag" => "8000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "10000 рублей",
        "tag" => "10000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "12000 рублей",
        "tag" => "12000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "15000 рублей",
        "tag" => "15000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "20000 рублей",
        "tag" => "20000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "25000 рублей",
        "tag" => "25000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "30000 рублей",
        "tag" => "30000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "35000 рублей",
        "tag" => "35000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "40000 рублей",
        "tag" => "40000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "45000 рублей",
        "tag" => "45000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "50000 рублей",
        "tag" => "50000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "60000 рублей",
        "tag" => "60000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "70000 рублей",
        "tag" => "70000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "80000 рублей",
        "tag" => "80000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "100000 рублей",
        "tag" => "100000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "150000 рублей",
        "tag" => "150000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "200000 рублей",
        "tag" => "200000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "250000 рублей",
        "tag" => "250000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "300000 рублей",
        "tag" => "300000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "400000 рублей",
        "tag" => "400000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "450000 рублей",
        "tag" => "450000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "500000 рублей",
        "tag" => "500000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "900000 рублей",
        "tag" => "900000-rub",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "1 млн рублей",
        "tag" => "1-mln",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "2 млн рублей",
        "tag" => "2-mln",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "3 млн рублей",
        "tag" => "3-mln",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    [
        "title" => "Крупный займ",
        "tag" => "big-zaem",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'sum',
        "category_id" => 1
    ],
    // срок
    [
        "title" => "на долгий срок",
        "tag" => "long-period",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 3 месяца",
        "tag" => "for-3-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на неделю",
        "tag" => "for-1-week",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на месяц",
        "tag" => "for-1-month",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 10 дней",
        "tag" => "for-10-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 100 дней",
        "tag" => "for-100-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 1 год",
        "tag" => "for-1-year",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на полгода",
        "tag" => "for-6-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 5 месяцев",
        "tag" => "for-5-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 5 лет",
        "tag" => "for-5-years",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 5 дней",
        "tag" => "for-5-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 4 месяца",
        "tag" => "for-4-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 4 года",
        "tag" => "for-4-years",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 3 дня",
        "tag" => "for-3-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 3 года",
        "tag" => "for-3-years",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 20 дней",
        "tag" => "for-20-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 21 день",
        "tag" => "for-21-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 2 недели",
        "tag" => "for-2-weeks",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 2 месяца",
        "tag" => "for-2-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 2 дня",
        "tag" => "for-2-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 2 года",
        "tag" => "for-2-years",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 24 месяца",
        "tag" => "for-24-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 18 месяцев",
        "tag" => "for-18-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 15 дней",
        "tag" => "for-15-days",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на 10 месяцев",
        "tag" => "for-10-months",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на день",
        "tag" => "for-1-day",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "на короткий период",
        "tag" => "for-short-period",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'period',
        "category_id" => 1
    ],
    [
        "title" => "На Webmoney",
        "tag" => "for-webmoney",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Visa Momentum",
        "tag" => "for-visa-momentum",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Золотую Корону",
        "tag" => "for-golden-crown",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "Через интернет",
        "tag" => "via-internet",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "С доставкой",
        "tag" => "with-delivery",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "Через Contact",
        "tag" => "via-contact",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "Через Госуслуги",
        "tag" => "via-gos",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "Переводом",
        "tag" => "by-transfer",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Юмани",
        "tag" => "on-yumani",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На электронный кошелек",
        "tag" => "na-electronic-wallet",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На сберкнижку",
        "tag" => "na-savings-account",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На неименную карту",
        "tag" => "na-unnamed-card",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На QIWI кошелек",
        "tag" => "na-qiwi",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На тинькофф",
        "tag" => "na-tinkoff",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На МТС",
        "tag" => "na-mts",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На почта банк",
        "tag" => "na-post-bank",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На ВТБ",
        "tag" => "na-vtb",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Альфа банк",
        "tag" => "na-alfa",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Халву",
        "tag" => "na-halva",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Совкомбанк",
        "tag" => "na-sovkombank",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Открытие",
        "tag" => "na-otkrytie",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Хоум Кредит",
        "tag" => "na-houm-credit",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На сбербанк",
        "tag" => "na-sberbank",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На карту мир",
        "tag" => "na-card-mir",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На Кукурузу",
        "tag" => "na-kukuruzu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На визу",
        "tag" => "na-visa",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На мастеркард",
        "tag" => "na-mastercard",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "На карту",
        "tag" => "na-card",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'method_obtaining',
        "category_id" => 1
    ],
    [
        "title" => "Без документов",
        "tag" => "bez-documentov",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "Без паспорта",
        "tag" => "bez-passport",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "Без СНИЛС и ИНН",
        "tag" => "bez-snils-i-inn",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "Без СНИЛС",
        "tag" => "bez-snils",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "Без справок о доходе",
        "tag" => "bez-spravok-o-dohode",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "Без справок и поручителей",
        "tag" => "bez-spravok-i-poruchiteley",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "По водительскому удостоверению",
        "tag" => "po-voditelskomu-udostovereniyu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "По военному билету",
        "tag" => "po-voennomu-biletu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "По загранпаспорту",
        "tag" => "po-zagranpassportu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "По паспорту",
        "tag" => "po-passportu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'docs',
        "category_id" => 1
    ],
    [
        "title" => "День в день",
        "tag" => "den-v-den",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "За 10 минут",
        "tag" => "za-10-minut",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "За 2 минуты",
        "tag" => "za-2-minuty",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "За 1 минуту",
        "tag" => "za-1-minutu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "Срочно",
        "tag" => "srochno",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "Быстро",
        "tag" => "bystro",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "Мгновенно",
        "tag" => "mgnovenno",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'rate_of_receipt',
        "category_id" => 1
    ],
    [
        "title" => "без процентов",
        "tag" => "bez-procentov",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'interest_rate',
        "category_id" => 1
    ],
    [
        "title" => "Под 0 процентов",
        "tag" => "pod-0-procentov",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'interest_rate',
        "category_id" => 1
    ],
    [
        "title" => "Под низкий процент",
        "tag" => "pod-nizkiy-procent",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'interest_rate',
        "category_id" => 1
    ],
    [
        "title" => "под минимальный платеж",
        "tag" => "pod-minimalnyi-platezh",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'interest_rate',
        "category_id" => 1
    ],
    [
        "title" => "под 0,8%",
        "tag" => "pod-08",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'interest_rate',
        "category_id" => 1
    ],
    [
        "title" => "С ежемесячным платежом",
        "tag" => "s-ezhemesyachnym-platezhom",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "На образование",
        "tag" => "na-obrazovanie",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "На покупку автомобиля",
        "tag" => "na-pokupku-avto",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "На развитие бизнеса",
        "tag" => "na-razvitie-biznesa",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Ночью",
        "tag" => "nochyu",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "С нулевым балансом",
        "tag" => "a-nulevym-balansom",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Круглосуточно",
        "tag" => "kruglosutochno",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без звонков",
        "tag" => "bez-zvonkov",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без комиссии",
        "tag" => "bez-komissii",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Через телефон",
        "tag" => "cherez-telefon",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без отказа",
        "tag" => "bez-otkaza",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без подтверждения доходов",
        "tag" => "bez-podtvezhdeniya-dochodov",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без поручителей",
        "tag" => "bez-poruchitelei",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без проверок",
        "tag" => "bez-proverok",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без прописки",
        "tag" => "bez-propiski",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Безработным",
        "tag" => "bezrabotnym",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без фото паспорта",
        "tag" => "bez-foto-passporta",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без электронной почты",
        "tag" => "bez-pochty",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без подписок",
        "tag" => "bez-podpisok",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "под рефинансирование",
        "tag" => "pod-pefinansirovanie",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "Без подтверждения личности",
        "tag" => "bez-podtverzhdeniya-lichnosti",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'features',
        "category_id" => 1
    ],
    [
        "title" => "До 70 лет",
        "tag" => "do-70-let",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'age',
        "category_id" => 1
    ],
    [
        "title" => "До 80 лет",
        "tag" => "do-80-let",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'age',
        "category_id" => 1
    ],
    [
        "title" => "C 18 лет",
        "tag" => "s-18-let",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'age',
        "category_id" => 1
    ],
    [
        "title" => "Без кредитной истории",
        "tag" => "bez-kreditnoy-istorii",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Для исправления кредитной истории",
        "tag" => "dly-ispravleniy",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Без проверки кредитной истории",
        "tag" => "bez-proverki-ki",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Должникам",
        "tag" => "dolzhnikam",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "С плохой кредитной историей",
        "tag" => "s-plohoy-ki",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "С большой кредитной нагрузкой",
        "tag" => "s-bolhoi-nagruzkoy",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Банкротам",
        "tag" => "bankrotam",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Пропащим",
        "tag" => "propachim",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],
    [
        "title" => "Пенсионарам",
        "tag" => "pensioneram",
        "template" => "post-for-zaem-template",
        "template_article_name" => 'credit_history_and_borrower_category',
        "category_id" => 1
    ],

];
