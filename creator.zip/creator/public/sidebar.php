<?php
global $post;
$sqlForSidebar = <<<SQL
            SELECT * FROM {$wpdb->get_blog_prefix()}creator_rubric
SQL;

$allRubricForSidebar = $wpdb->get_results($sqlForSidebar);

$rubricsByCategory = [];
foreach ($allRubricForSidebar as $rubric) {
    if (empty($rubricsByCategory[$rubric->template_article_name])) {
        $rubricsByCategory[$rubric->template_article_name] = [$rubric];

        continue;
    }
    array_push($rubricsByCategory[$rubric->template_article_name], $rubric);
}
?>


<div class="sidebar-creator">
    <div class="creator-sidebar-item">
        <?php
        foreach ($rubricsByCategory as $key => $rubricByCategory) {
            $sqlForRubricByCategory = <<<SQL
                            SELECT * FROM {$wpdb->get_blog_prefix()}creator_template_article_info WHERE category = '$key'
SQL;
            $catName = $wpdb->get_results($sqlForRubricByCategory)[0];

            ?>
            <div class="creator-sidebar-category-name">
                <?= $catName->name ?>
            </div>
            <?php
            $counter = 0;
            foreach ($rubricByCategory as $rubric) {

                $pageUri = explode("_", $post->post_name);
                if ($pageUri[2] == $rubric->tag) {
                    continue;
                }


                $string = $rubric->title;
                $char = mb_strtoupper(substr($rubric->title, 0, 2), "utf-8"); // это первый символ
                $string[0] = $char[0];
                $string[1] = $char[1];


                $pageUri = explode("_", $post->post_name);
                ?>
                <div class="creator-sidebar-category-value <?= $key . "_selectors" ?> " id="<?= $key . $rubric->tag ?>"
                    <?php
                    if ($counter > 5) {
                        echo 'hidden';
                    }
                    ?>
                >
                    <a href="<?= home_url("/{$pageUri[0]}/zaem/{$rubric->tag}") ?>">
                        <?= $string ?>
                    </a>
                </div>
                <?php
                $counter++;
            }
            if ($counter > 5) {
                ?>

                <span class="creator-show-more" id="showMoreBtn_<?= $key ?>" clickCount="0"
                      onclick="showMore('<?= $key ?>')">Показать еще</span>
            <?php }
        } ?>
    </div>
</div>


<script>

    function showMore(category) {

        let elementList = document.querySelectorAll("." + category + "_selectors");

        let count = 0
        for (let i in elementList) {
            if (count > 5) {
                break
            }
            if (elementList[i].hidden === true) {
                elementList[i].removeAttribute("hidden")
                count++
            }
        }
        if (count <= 6) {
            let btn = document.getElementById("showMoreBtn_"+category)
            btn.setAttribute("hidden", true)
        }
    }
</script>

