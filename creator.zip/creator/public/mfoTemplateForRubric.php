<?php
$urlReviews = str_replace('http://onlain-zaim/', '', get_page_link(get_the_ID()));
$urlId = url_to_postid('http://onlain-zaim/mfo/' . $urlReviews . '/reviews');

$reviews = getListReview(['id_mfo' => $urlId, 'show' => true]);
$rate = getRatePostReview($urlId);

if ($rate == 0) {
    $rate = get_field('rate');
}
?>


<div class="catalog-mfo-item mfoInCreatorPage" numberMfo="<?= $count ?>"
    <?php
    if ($count >= 10) {
        echo "hidden";
    }
    ?>
>
    <div class="row">
        <div class="catalog-mfo-item-block col-xs-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
            <div class="catalog-mfo-item-logo">
                <a href="<?= the_permalink() ?>" target="_blank" class="">
                    <img src="<?php the_field('logo_small'); ?>"/></a>
                <span class="rating"><span class="star"></span><?= $rate ?></span>
            </div>
            <div class="catalog-mfo-item-term">
                Срок
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('term1')) ?>-<?= stripcslashes(get_field('term2')) ?> дней</span>
            </div>

            <div class="catalog-mfo-item-approved min1200">
                Одобрено
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('percent_appruve')) ?>%</span>
            </div>

            <div class="wrap-popular-mfo-item-more max768">
                <a href="<?= the_permalink() ?>" target="_blank" class="popular-mfo-item-more">Подробнее</a>
            </div>
        </div>

        <div
                class="catalog-mfo-item-block 1200max max1200 pl50 col-xs-4 col-sm-4 col-md-4 col-lg-4 col-xl-4">
            <div class="catalog-mfo-item-approved">
                Одобрено
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('percent_appruve')) ?>%</span>
            </div>

            <div class="catalog-mfo-item-bid">
                Ставка
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('percent')) ?>%</span>
            </div>

        </div>

        <div class="catalog-mfo-item-block pl50 col-xs-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">

            <div class="catalog-mfo-item-issued">
                Выдано займов
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('n_loans_issued')) ?></span>
            </div>

            <div class="catalog-mfo-item-sum">
                Сумма до
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('sum2')) ?> &#8381;</span>
            </div>

            <div class="catalog-mfo-item-bid min1200">
                Ставка
                &nbsp;&nbsp;&nbsp;<span><?= stripcslashes(get_field('percent')) ?>%</span>
            </div>

            <a href="<?= stripcslashes(get_field('referal')) ?>" target="_blank"
               class="popular-mfo-item-take-money">Получить деньги</a>

            <div class="wrap-popular-mfo-item-more min768">
                <a href="<?= the_permalink() ?>" target="_blank" class="popular-mfo-item-more">Подробнее</a>
            </div>
        </div>
    </div>
    <p class="markirovka">Реклама | <?php the_field('yface'); ?></p>
</div>
