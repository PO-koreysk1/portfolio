<?php
$rand = rand(1, 4);

global $wpdb;
$prefix = $wpdb->get_blog_prefix();
$queryParams = explode("_", get_the_title());

if (in_array("mfo", $queryParams)) {
    $postTemplate = "mfoTemplate";
} else {
    $postTemplate = $wpdb->get_results("SELECT template FROM " . $prefix . "creator_rubric WHERE tag = '{$queryParams[2]}';")[0]->template;

}
include __DIR__ . "/../templates/$postTemplate.php";