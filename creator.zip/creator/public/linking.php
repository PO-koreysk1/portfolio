<?php

$regions = $wpdb->get_results("SELECT * FROM {$wpdb->get_blog_prefix()}creator_region");
?>


<div class="creator-linking">
    <h3 class="creator-linking-header">
        Займы в других регионах
    </h3>
    <div class="creator-linking-body">
        <?php
        foreach ($regions as $region) {
            $sqlRegionForLinking = <<<SQL
                    SELECT  * FROM {$wpdb->get_blog_prefix()}creator_city WHERE region_code = {$region->code}
SQL;

            $citiesInRegion = $wpdb->get_results($sqlRegionForLinking);

            ?>
            <div class="creator-linking-region-body">
                <div class="creator-linking-region-body-header">
                    <b><?= $region->name ?></b>
                </div>
                <?php
                foreach ($citiesInRegion as $city) {
                    ?>
                    <div class="creator-sidebar-category-value">
                        <a><?="в " . sklonyator($city->name) ?></a>
                    </div>
                <?php

                }

                ?>
            </div>

        <?php

        }
        ?>

    </div>
</div>