<?php
/*
Plugin Name: CreatorPage
Plugin URI: http://aletheme.com
Description: Автоматическое создание страниц
Version: 1.0
Author: @po_koreyski
Author URI: https://t.me/po_koreyski
License: GPLv2 or later
Text Domain: creator
*/

if (!defined('ABSPATH')) {
    die;
}


class CreatePost
{
    /**
     * @return void
     */
    public function register(): void
    {
        add_action("admin_enqueue_scripts", [$this, "enqueue_admin"]);
        add_action("admin_enqueue_scripts", [$this, "register_admin"]);
        add_action("wp_enqueue_scripts", [$this, "register_front"]);
        add_action('admin_menu', [$this, "addAdminMenu"]);
        add_action("init", [$this, "registerPostType"]);
        add_action("init", [$this, "registerTaxonomy"]);


    }

    /**
     * Добавление в меню вкладки
     *
     * @return void
     */
    public function addAdminMenu(): void
    {
        add_menu_page(
            esc_html__('Creator Page', 'creator'),
            esc_html__('Creator', 'creator'),
            'manage_options',
            'creator-page',
            function () {
                require_once plugin_dir_path(__FILE__) . 'admin/creator-admin.php';
            },
            'dashicons-category',
            100
        );
    }

    /**
     * Добавление типа поста для всех записей, генерирующихся после
     *
     * @return void
     */
    public function registerPostType(): void
    {
        register_post_type(
            "creator",
            [
                "public" => true,
                "show_ui" => true,
                "menu_position" => 101,
                "menu_icon" => "dashicons-align-right",
                "rewrite" => true,
                "label" => "Записи Creator",
                "publicly_queryable" => true,
            ]

        );
    }

    /**
     * Создает таксономии для записей
     *
     * @return void
     */
    public function registerTaxonomy()
    {

        register_taxonomy(
            "creator",
            "creator",
            [
                "label" => "Таксономии",
                "public" => true,
                "hierarchical" => true,
                "rewrite" => [
                    "hierarchical" => true
                ],
                "slug" => "test"

            ]
        );
    }

    /**
     * Метод, вызывающийся при активации плагина
     *
     * @return void
     */
    public function activation(): void
    {
        $this->createTable();
        $this->insertDataIntoRegionTable();
        $this->insertDataIntoCityTable();
        $this->insertDataIntoCategoryTable();
        $this->insertDataIntoRubricTable();
        $this->insertDataIntoTemplateArticleMfoTable();

        flush_rewrite_rules();
    }

    /**
     * Создает записи в таблице регионов
     *
     * @return void
     */
    public function insertDataIntoRegionTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        $regions = require __DIR__ . "/data/region.php";
        foreach ($regions as $region) {
            $wpdb->insert(
                $prefix . "creator_region",
                [
                    'name' => $region['name'],
                    'code' => $region['code'],
                ]
            );
        }
    }

    /**
     * Создает записи в таблице городов
     *
     * @return void
     */
    public function insertDataIntoCityTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        $cities = require __DIR__ . "/data/city.php";
        foreach ($cities as $city) {
            $wpdb->insert(
                $prefix . "creator_city",
                [
                    'name' => $city['name'],
                    'tag' => $city['tag'],
                    "region_code" => $city["region_code"],
                    "category_id" => str_replace(",,", ",", ",{$city["category_id"]},")
                ]
            );
        }
    }

    /**
     * Создает записи в таблице подразделов
     *
     * @return void
     */
    public function insertDataIntoCategoryTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        $chapters = require __DIR__ . "/data/category.php";
        foreach ($chapters as $chapter) {
            $wpdb->insert(
                $prefix . "creator_category",
                [
                    'name' => $chapter['name'],
                    'tag' => $chapter['tag'],
                ]
            );
        }
    }

    /**
     * Создает записи в таблице рубрик
     *
     * @return void
     */
    public function insertDataIntoRubricTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        $rubrics = require __DIR__ . "/data/rubric.php";
        foreach ($rubrics as $rubric) {
            $wpdb->insert(
                $prefix . "creator_rubric",
                [
                    'title' => $rubric['title'],
                    'tag' => $rubric['tag'],
                    "template" => $rubric["template"],
                    "category_id" => $rubric["category_id"],
                    "template_article_name" => $rubric["template_article_name"],
                ]
            );
        }
    }


    /**
     * Создает записи в таблице шаблонов записей
     *
     * @return void
     */
    public function insertDataIntoTemplateArticleMfoTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        // todo добавить использование сервиса по замене слов

        $allTemplate = require __DIR__ . "/data/templateArticle.php";
        foreach ($allTemplate as $template) {
            $wpdb->insert(
                $prefix . "creator_template_article_info",
                [
                    'category' => $template['category'],
                    'name' => $template['name'],
                    'title' => $template['title'],
                    'content_before_mfo' => $template['content_before_mfo'],
                    'content_after_mfo' => $template['content_after_mfo'],
                    'meta_title' => $template['meta_title'],
                    'meta_description' => $template['meta_description'],

                ]
            );
        }
    }

    /**
     * Метод, вызывающийся при деактивации плагина
     *
     * @return void
     */
    public function deactivation(): void
    {
        $this->cleanTable();

        flush_rewrite_rules();
    }

    /**
     * Функция по очистке таблиц созданных плагином
     *
     * @return void
     */
    public function cleanTable(): void
    {
        global $wpdb;
        $prefix = $wpdb->get_blog_prefix();

        $table = $prefix . "creator_region";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));

        $table = $prefix . "creator_city";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));

        $table = $prefix . "creator_category";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));

        $table = $prefix . "creator_rubric";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));

        $table = $prefix . "creator_mfo";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));

        $table = $prefix . "creator_template_article_info";
        $wpdb->query($wpdb->prepare("TRUNCATE TABLE $table"));
    }

    public function register_admin(): void
    {
        wp_register_style("creator_style_admin", plugins_url("/assets/admin/styles.css", __FILE__));
        wp_register_script("creator_script_admin", plugins_url("/assets/admin/scripts.js", __FILE__));
        wp_register_script("creator_script_htmx", plugins_url("/assets/admin/htmx.min.js", __FILE__));
    }

    /**
     * Функция подключения скриптов и стилей к админке
     *
     * @return void
     */
    public function enqueue_admin(): void
    {
        wp_enqueue_style("creator_style_admin");
        wp_enqueue_script("creator_script_admin");
        wp_enqueue_script("creator_script_htmx");
    }

    public function register_front(): void
    {
        wp_register_style("creator_style_front", plugins_url("creator/assets/front/styles.css", ),[], null);
        wp_register_script("creator_script_front", plugins_url("creator/assets/front/scripts.js",), [], null);
        wp_enqueue_style("creator_style_front");
        wp_enqueue_script("creator_script_front");
    }



    private function createTable(): void
    {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $charsetCollate = $wpdb->get_charset_collate();

        $prefix = $wpdb->get_blog_prefix();

        dbDelta($this->createRegionTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createCityTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createChapterTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createRubricTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createMfoTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createOrganizationsAttachedToPostsTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createMfoInfoTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createTemplateArticleInfoTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createUniqueTemplateForArticleTable(prefix: $prefix, charsetCollate: $charsetCollate));
        dbDelta($this->createCityWithUniqueTextTable(prefix: $prefix, charsetCollate: $charsetCollate));
    }


    /**
     * Возвращает SQL запрос для создания таблицы с регионами
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createRegionTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_region";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            name varchar(100) NOT NULL default '',
	            code int(5) NOT NULL,
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с городами
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createCityTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_city";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            name varchar(50) NOT NULL default '',
	            tag varchar(50) NOT NULL default '',
	            region_code bigint(7) NOT NULL,
                category_id varchar(255) NOT NULL default '',
	            PRIMARY KEY  (id),
	            KEY region_id (region_code)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с группами категорий
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createChapterTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_category";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            name varchar(50) NOT NULL default '',
	            tag varchar(50) NOT NULL default '',
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }


    /**
     * Возвращает SQL запрос для создания таблицы с рубриками
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createRubricTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_rubric";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            title varchar(50) NOT NULL default '',
	            tag varchar(50) NOT NULL default '',
	            template varchar(25) NOT NULL default '',
	            category_id bigint(7) NOT NULL,
	            template_article_name varchar(100) NOT NULL DEFAULT '',
	            PRIMARY KEY  (id),
	            KEY subchapter_id (category_id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с рубриками
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createMfoTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_mfo";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            name varchar(50) NOT NULL default '',
	            tag varchar(50) NOT NULL default '',	        
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы отображающей связи постов и организаций
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createOrganizationsAttachedToPostsTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_organizations_attached_to_posts";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            post_name varchar(50) NOT NULL default '',
	            mfo_ids text NOT NULL default '',
	            is_close integer(1) NOT NULL default 0 COMMENT '0 - закрыт, 1 - открыт',	        
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с информацией об мфо
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createMfoInfoTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_mfo_info";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            name varchar(50) NOT NULL default '',
	            logo_link varchar(255) NOT NULL default '',	        
	            mfo_id integer(8) NOT NULL,	        
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с информацией о шаблонах
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createTemplateArticleInfoTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_template_article_info";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            category varchar(50) NOT NULL default '',
	            name varchar(50) NOT NULL default '',
	            title varchar(50) NOT NULL default '',
	            content_before_mfo MEDIUMTEXT NOT NULL default '',
	            content_after_mfo MEDIUMTEXT NOT NULL default '',
	            meta_title varchar(255) NOT NULL default '',
	            meta_description MEDIUMTEXT NOT NULL default '',
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с уникальными шаблонами для записей
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createUniqueTemplateForArticleTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_unique_template_for_article";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            city_tag varchar(50) NOT NULL default '',
	            category varchar(50) NOT NULL default '',
	            rubric varchar(50) NOT NULL default '',
	            article varchar(50) NOT NULL default '',
	            name varchar(50) NOT NULL default '',
	            title varchar(50) NOT NULL default '',
	            content_before_mfo MEDIUMTEXT NOT NULL default '',
	            content_after_mfo MEDIUMTEXT NOT NULL default '',
	            meta_title varchar(255) NOT NULL default '',
	            meta_description MEDIUMTEXT NOT NULL default '',
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }

    /**
     * Возвращает SQL запрос для создания таблицы с городами для которых сгенерированы уникальные тексты
     *
     * @param string $prefix
     * @param string $charsetCollate
     * @return string
     */
    private function createCityWithUniqueTextTable(string $prefix, string $charsetCollate): string
    {
        $tableName = $prefix . "creator_city_with_unique_text";

        return "CREATE TABLE $tableName (
                id  bigint(7) unsigned NOT NULL auto_increment,
	            city_name varchar(50) NOT NULL default '',
	            PRIMARY KEY  (id)
	            )
	            $charsetCollate;";
    }
}

if (class_exists("CreatePost")) {
    $createPost = new CreatePost();
    $createPost->register();
}

register_activation_hook(__FILE__, [$createPost, "activation"]);
register_deactivation_hook(__FILE__, [$createPost, "deactivation"]);

