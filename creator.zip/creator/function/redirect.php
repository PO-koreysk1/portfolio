<?php
//
//
//function getLinks(): array
//{
//    $links = [];
//
//    global $wpdb;
//
//
//    $sql = <<<SQL
//SELECT `post_name` FROM {$wpdb->get_blog_prefix()}posts WHERE `post_type` = 'creator';
//SQL;
//
//    $postNames = $wpdb->get_results($sql);
//
//    foreach ($postNames as $postName) {
//        $links[] = [
//            'old' => "/creator/{$postName->post_name}/",
//            'new' => "/" . str_replace("_", "/", $postName->post_name) . "/"
//        ];
//    }
//    return $links;
//}
//
//function true_301_redirect()
//{
//
//    /* в массиве указываем все старые=>новые ссылки  */
//    $links = getLinks();
//
//    foreach ($links as $link) :
//        if (urldecode($_SERVER['REQUEST_URI']) == $link['old']) :
//            wp_redirect(site_url($link['new']), 301);
//            exit();
//        endif;
//    endforeach;
//}
//
//add_action('template_redirect', 'true_301_redirect');
//
//function true_request($query)
//{
//
//    $data = getLinks();
//    $newLinks = [];
//    foreach ($data as $item) {
//        $newLinks[] = $item["new"];
//    }
//
//    $url_zapros = urldecode($_SERVER['REQUEST_URI']);
//
//
//    /* для записей */
//    if (in_array($url_zapros, $newLinks)){
//        $query['name'] = substr(substr(str_replace('/', "_", $url_zapros), 1), 0, -1);
//        $query['creator'] = substr(substr(str_replace('/', "_", $url_zapros), 1), 0, -1);
//        $query['post_type'] = "creator";
//        unset($query["category_name"]);
//
//
//    }
//
//    return $query;
//}
//
//add_filter('request', 'true_request', 9999, 1);
//
//function true_posts_links($url, $post)
//{
//    if (!is_object($post)){
//        $post = get_post($post);
//    }
//
//    $replace = $post->post_name;
//
//    $data = getLinks();
//    $links = [];
//    foreach ($data as $item) {
//        $links[] = $item["old"];
//    }
//
//    if (in_array($post->post_name, $links)) {
//        $replace = str_replace('_', '/', $post->post_name);
//    }
//
//    $url = str_replace($post->post_name, $replace, $url);
//    return $url;
//}
//
//add_filter('post_link', 'true_posts_links', 'edit_files', 2);
//add_filter('page_link', 'true_posts_links', 'edit_files', 2);
//add_filter('post_type_link', 'true_posts_links', 'edit_files', 2);
//
