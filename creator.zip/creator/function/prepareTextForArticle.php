<?php
function replaceCatName($string, $rubric): string
{
    global $wpdb;

    $sql = <<<SQL
                SELECT * FROM {$wpdb->get_blog_prefix()}creator_rubric WHERE `tag` = '$rubric'
SQL;

    $catName = $wpdb->get_results($sql)[0];
    $titleArr = explode(" ", $catName->title);
    $titleArr[0] = mb_strtolower($titleArr[0]);
    $catNameTitle = implode(" ", $titleArr);

    return str_replace("[cat_name]", $catNameTitle, $string);
}

function getCityName($city): string
{
    global $wpdb;

    $sql = <<<SQL
                SELECT * FROM {$wpdb->get_blog_prefix()}creator_city WHERE `tag` = '$city'
SQL;

    return $wpdb->get_results($sql)[0]->name;
}


function replacePredlog($string, $city): string
{

    $predlog = sklonyator( getCityName($city));

    return str_replace("[predlog]", $predlog, $string);
}

function replaceImenitel($string, $city): string
{
    $city = getCityName($city);

    return str_replace("[imenitel]", $city, $string);
}

function replaceTag($string, $rubric = '', $city = ''): string
{
    if (!empty($rubric)) {
        $string = replaceCatName(string: $string, rubric: $rubric);
    }
    if (!empty($city)) {
        $string = replacePredlog(string: $string, city: $city);
    }

    if (!empty($city)) {
        $string = lcfirst(replaceImenitel(string: $string, city: $city));
    }

    return $string;
}

function sklonyator($cityName): string
{

    $glasArr = ['а' => 'а', 'у' => 'у', 'о' => 'о', 'ы' => 'ы', 'и' => 'и', 'э' => 'э', 'я' => 'я', 'ю' => 'ю', 'ё' => 'ё', 'е' => 'е', 'ь' => 'ь'];
    $glas = mb_substr($cityName, -1);
    if (!isset($glasArr[$glas])) {

        return $cityName . 'е';
    }
    $result = mb_substr($cityName, 0, -1);

    if ('ь' === $glasArr[$glas] || "и" === $glasArr[$glas]) {
        return $result . 'и';
    }

    return $result . 'е';

}