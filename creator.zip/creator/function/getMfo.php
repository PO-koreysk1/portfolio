<?php
function getMfoForSingleCreator(array $mfoNames)
{
    if (!empty($mfoNames)) {
        $args = array(
            'post_type' => 'mfo',
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'mfo_categories',
                    'field'    => 'id',
                    'terms'    => 1707
                )
            ),
            "post_name__in" => $mfoNames,
            "posts_per_page" => -1,
            'order' => 'ASC',
            'meta_key' => 'catalogpos',
            'orderby' => 'meta_value_num id',
            'post_parent' => 0
        );

        $query = new WP_Query($args);
        if ($query->have_posts()) :
            $count = 0;
            while ($query->have_posts()) {
                $query->the_post();

                include __DIR__ . "/../public/mfoTemplateForRubric.php";
                $count++;
            }
            wp_reset_postdata();
            if (count($query->posts )> 10) {
                ?>

                <div id="mfo_creator_pagination" style="display: flex; justify-content: center">
                    <span class="btn-oz" id="btn_mfo_creator_pagination" onclick="showMoreMfo()">Показать еще</span>
                </div>
            <?php }
            ?>
            <script>
                function showMoreMfo() {
                    let mfos = document.querySelectorAll(".mfoInCreatorPage")


                    let count = 0
                    for (let i in mfos) {

                        if (count > 5) {
                            break
                        }
                        if (mfos[i].hidden === true) {
                            mfos[i].removeAttribute("hidden")
                            count++
                        }


                    }
                    if (count < 5) {
                        let btn = document.getElementById("mfo_creator_pagination")
                        btn.style.display = 'none'
                    }
                }
            </script>
        <?php

        endif;
    }


}